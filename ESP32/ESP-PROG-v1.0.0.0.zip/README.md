## License

This source code is released as Free Software under Apache License Version 2. See the accompanying [LICENSE](LICENSE) file for a copy.